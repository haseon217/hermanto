"""skrvm implements RVM models."""

from .rvm import RVR, RVC

__all__ = ['RVR', 'RVC']

__version__ = '0.1.0a1'
